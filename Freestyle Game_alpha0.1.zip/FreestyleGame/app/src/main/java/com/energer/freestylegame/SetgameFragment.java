package com.energer.freestylegame;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class SetgameFragment extends Fragment implements View.OnClickListener {
    private RecyclerView recyclerView;
    private MyAdapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private HomeFragment.OnButtonClickedListener mCallback;

    private TextView aff_nb_players;

    public SetgameFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View result=inflater.inflate(R.layout.fragment_setgame, container, false);

        //deserialization :
        recyclerView=(RecyclerView)result.findViewById(R.id.recyclerview);
        aff_nb_players=(TextView)result.findViewById(R.id.textview_nbplayer);

        //other :

        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        mAdapter=new MyAdapter();
        recyclerView.setAdapter(mAdapter);
        recyclerView.setHasFixedSize(true);

        //setListener
        setListener(result);


        // Inflate the layout for this fragment
        return result;
    }

    public interface OnButtonClickedListener {
        public void onButtonClicked(View view);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        mCallback = (HomeFragment.OnButtonClickedListener) getActivity();
    }



    @Override
    public void onClick(View view) {
        mCallback.onButtonClicked(view);
    }


    private void setListener(View v){
        v.findViewById(R.id.button_moins).setOnClickListener(this);
        v.findViewById(R.id.button_plus).setOnClickListener(this);
    }

    public void setAffNbPlayer(int nb){
        aff_nb_players.setText(Integer.toString(nb));
    }

    public MyAdapter getAdapter(){
        return mAdapter;
    }
}
