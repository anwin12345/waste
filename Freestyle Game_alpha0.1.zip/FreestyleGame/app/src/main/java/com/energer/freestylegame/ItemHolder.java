package com.energer.freestylegame;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ItemHolder extends RecyclerView.ViewHolder {
    private EditText name;
    private ImageView img;

    public ItemHolder(@NonNull View itemView) {
        super(itemView);
        this.name=itemView.findViewById(R.id.pseudo_player);
        this.img=itemView.findViewById(R.id.img_player);
    }

    public ImageView getImg() {return img;}

    public EditText getName() {return name;}
}
