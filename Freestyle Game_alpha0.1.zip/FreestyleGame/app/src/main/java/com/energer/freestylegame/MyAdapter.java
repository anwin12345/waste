package com.energer.freestylegame;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>  {
    private ArrayList<Player> listPlayer;

    public MyAdapter(ArrayList<Player> mlist){
        this.listPlayer=mlist;
    }

    public MyAdapter(){
        this.listPlayer=new ArrayList<Player>();
        listPlayer.add(new Player("Player #1"));
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_item,parent,false);
        ItemHolder mViewHolder=new ItemHolder(itemView);
        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ItemHolder mHolder=(ItemHolder)holder;
        Player player=listPlayer.get(position);
        mHolder.getName().setText(player.getName());
        mHolder.getImg().setImageResource(player.getImg());
    }

    @Override
    public int getItemCount() {
        return listPlayer.size();
    }

    public ArrayList<Player> getListPlayer(){
        return listPlayer;
    }
}
