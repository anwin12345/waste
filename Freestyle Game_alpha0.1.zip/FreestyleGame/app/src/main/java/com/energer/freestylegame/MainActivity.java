package com.energer.freestylegame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements HomeFragment.OnButtonClickedListener, SetgameFragment.OnButtonClickedListener{

    private BottomNavigationView bottomNav;
    private TextView aff_nb_player;
    private SetgameFragment setgameFragment;
    Fragment selectedFragment=null;
    private MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //deserialization :

        bottomNav=(BottomNavigationView)findViewById(R.id.bottom_navigation);

        bottomNav.setOnNavigationItemSelectedListener(navListener);


        //other :
        bottomNav.setSelectedItemId(R.id.nav_home);
    }

    //Listener :

    private BottomNavigationView.OnNavigationItemSelectedListener navListener=new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            switch (menuItem.getItemId()){
                case R.id.nav_rec:
                    selectedFragment=new RecFragment();
                    break;
                case R.id.nav_home:
                    selectedFragment=new HomeFragment();
                    break;
                case R.id.nav_discover:
                    selectedFragment=new DiscoverFragment();
                    break;
            }

            getSupportFragmentManager().beginTransaction().replace(R.id.frame_container,selectedFragment).commit();

            return true;
        }
    };



    //listener HomeFragment
    @Override
    public void onButtonClicked(View view) {
        if(setgameFragment!=null){
            myAdapter=setgameFragment.getAdapter();
        }

        switch (view.getId()){
            case R.id.play:
                setgameFragment=new SetgameFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_container,setgameFragment).commit();
                break;

            case R.id.button_moins:
                if(myAdapter.getItemCount()>1){
                    myAdapter.getListPlayer().remove((myAdapter.getItemCount()-1));
                    myAdapter.notifyDataSetChanged();
                    setgameFragment.setAffNbPlayer(myAdapter.getItemCount());
                }
                break;

            case R.id.button_plus:
                myAdapter.getListPlayer().add(new Player("Player #"+(myAdapter.getItemCount()+1)));
                myAdapter.notifyDataSetChanged();
                setgameFragment.setAffNbPlayer(myAdapter.getItemCount());
                break;

        }
    }

}
