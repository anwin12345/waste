package com.energer.freestylegame;

public class Player {
    private String name;
    private int img;
    private int id;

    public Player(String name){
        this.name=name;
        this.img=R.drawable.user;
    }

    public Player(String name, int id){
        this.name=name;
        this.id=id;
    }

    public String getName(){return this.name;}

    public int getImg() {return img;}

    public void setImg(int img) {this.img = img;}

    public void setName(String name) {this.name = name;}

    public int getId() {return id;}

    public void setId(int id) {this.id = id;}
}
